# Étapes de développement

1. Installer Node.js et npm sur votre machine
2. Extraire ce projet
3. Ouvrir un terminal et naviguer dans le dossier
4. Lancer `npm install`
5. Démarrer l'application avec `node server.js`
6. Ouvrir http://localhost:3000 dans votre navigateur

### Identifiants de connexion
- Nom d'utilisateur : Pablo
- Mot de passe : 220912
- Rôles disponibles : élève, prof, directeur (à choisir dans la liste déroulante)
